# DevSecOps With Docker Scout Hotstar Clone

#BLOG
https://mrcloudbook.com/devsecops-ci-cd-deploying-a-secure-hotstar-clone-even-if-youre-not-a-pro/
